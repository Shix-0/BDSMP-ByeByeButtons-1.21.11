package pl.bdsmp.byebyebuttons.mixin;

import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;

@Mixin(Screen.class)
public interface ScreenAccessor {
    @Invoker("children")
    List<? extends GuiEventListener> bdsmp$getChildren();

    @Invoker("removeWidget")
    void bdsmp$removeWidget(GuiEventListener widget);
}
