package pl.bdsmp.byebyebuttons.mixin;

import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void bdsmp$removeExtraTitleIcons(CallbackInfo ci) {
        // FancyMenu can add its screen widgets after TitleScreen.init has finished.
        // Recheck immediately before rendering and use Screen.removeWidget so each
        // icon is removed from the input, render, and narration lists together.
        ((ScreenAccessor) this).bdsmp$getChildren().stream()
                .filter(widget -> widget instanceof ImageButton)
                .toList()
                .forEach(widget -> ((ScreenAccessor) this).bdsmp$removeWidget(widget));
    }
}
